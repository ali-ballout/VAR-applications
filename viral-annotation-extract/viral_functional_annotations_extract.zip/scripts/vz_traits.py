import os,re,gzip,csv,pickle,datetime,html
from collections import defaultdict,Counter
T=pickle.load(open('/home/claude/out/tax.pkl','rb'))
fam=T['fam']; studyL=T['study']; rows_meta=T['rows']
D='/home/claude/out/deliver'; VZ='/home/claude/out/raw/viralzone'
RETR=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
fams=sorted({fam[t] for t in studyL if fam[t]})
nf=sorted({r['viral_family'] for r in rows_meta if r['viral_family']})
allfam=sorted(set(fams)|set(nf))
print(f"distinct study families: NCBITaxon={len(fams)}, input-file={len(nf)}, union={len(allfam)}")
idx=[]
for f in os.listdir(VZ):
    if not f.endswith('.html.gz'): continue
    pid=f[3:-8]
    h=gzip.open(f'{VZ}/{f}','rt',encoding='utf-8',errors='replace').read()
    t=re.search(r'<title>([^<]*)</title>',h); h1=re.search(r'<h1[^>]*>([^<]*)',h)
    idx.append((pid,html.unescape((t.group(1) if t else '').replace('~ ViralZone','').strip()),
                html.unescape((h1.group(1) if h1 else '').strip()),f))
# match family name to page title/h1
HOST_PAT=re.compile(r'host|receptor|tropism|transmission|vector|reservoir|patholog|epidemiolog|zoonos|human diseas|species range',re.I)
STRIP=re.compile(r'<script.*?</script>|<style.*?</style>',re.S)
TAG=re.compile(r'<[^>]+>')
matched=defaultdict(list)
for pid,title,h1,f in idx:
    for fm in allfam:
        base=fm.lower()
        if base and (base==title.lower() or base==h1.lower() or re.search(r'\b'+re.escape(base)+r'\b',(title+' '+h1).lower())):
            matched[fm].append((pid,title or h1,f))
print(f"families matched to >=1 ViralZone page: {len(matched)}/{len(allfam)}")
nrow=0; excl=Counter()
with open(f'{D}/viralzone_family_traits.tsv','w',newline='') as out:
    w=csv.writer(out,delimiter='\t',lineterminator='\n')
    w.writerow(['viral_family','viralzone_page_id','viralzone_url','viralzone_page_title',
      'section_heading','trait_text','inclusion_status','exclusion_reason','mapping_type',
      'mapping_note','controlled_trait_id','source_resource','source_release_date',
      'retrieved_utc','temporally_eligible','eligibility_basis','source_file'])
    for fm,pages in sorted(matched.items()):
        for pid,title,f in pages:
            h=gzip.open(f'{VZ}/{f}','rt',encoding='utf-8',errors='replace').read()
            h=STRIP.sub(' ',h)
            secs=re.split(r'(<h[23][^>]*>.*?</h[23]>)',h)
            curh='(page intro)'
            for part in secs:
                m=re.match(r'<h[23][^>]*>(.*?)</h[23]>',part,re.S)
                if m:
                    curh=html.unescape(TAG.sub('',m.group(1))).strip()[:120] or '(untitled)'
                    continue
                txt=html.unescape(TAG.sub(' ',part))
                txt=re.sub(r'\s+',' ',txt).strip()
                if len(txt)<40: continue
                leak=HOST_PAT.search(curh) or HOST_PAT.search(txt[:400])
                if leak:
                    status='EXCLUDED_HOST_LEAKAGE_RISK'
                    reason=f'matched host/association pattern: {leak.group(0)!r}'
                    excl[reason.split(':')[0]]+=1
                    txt=''
                else:
                    status='INCLUDED_FAMILY_LEVEL'; reason=''
                w.writerow([fm,pid,f'https://viralzone.expasy.org/{pid}',title,curh,txt[:1200],
                  status,reason,'FAMILY_ONLY',
                  'family-level descriptive text; NOT promoted to species-level annotation for any study TaxID',
                  '','ViralZone (ExPASy/SIB)','undated_rolling_resource',RETR,'false',
                  'ViralZone publishes no dated release; retrieval date only','raw/viralzone/'+f])
                nrow+=1
print(f"viralzone trait rows: {nrow:,} (excluded-for-leakage sections: {sum(excl.values()):,})")
