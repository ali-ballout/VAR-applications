import json,urllib.request,concurrent.futures as cf,pickle
T=pickle.load(open('/home/claude/out/tax.pkl','rb')); study=set(T['study'])
tx=[int(x) for x in open('/home/claude/out/taxids_with_proteins.txt').read().split()]
ex=[t for t in tx if t in study]; de=[t for t in tx if t not in study]
def hits(b):
    u='https://www.ebi.ac.uk/QuickGO/services/annotation/search?limit=1&taxonId='+','.join(map(str,b))
    for _ in range(3):
        try:
            with urllib.request.urlopen(u,timeout=90) as r: return json.load(r).get('numberOfHits',0)
        except Exception: pass
    return -1
def tot(ids,label):
    B=[ids[i:i+50] for i in range(0,len(ids),50)]
    s=0;f=0
    with cf.ThreadPoolExecutor(6) as e:
        for h in e.map(hits,B):
            if h<0: f+=1
            else: s+=h
    print(f"{label:<42}{s:>12,}  ({len(B)} batches, {f} failed)")
    return s
a=tot(ex,'exact study taxa with proteins (257)')
b=tot(de,'descendant taxa with proteins (24,890)')
print(f"{'TOTAL annotations to retrieve':<42}{a+b:>12,}")
print(f"est. raw TSV ~{(a+b)*165/1e9:.2f} GB  -> gzipped ~{(a+b)*165/1e9*0.18:.2f} GB")
