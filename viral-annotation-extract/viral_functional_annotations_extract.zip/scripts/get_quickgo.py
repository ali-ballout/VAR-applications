import os,gzip,urllib.request,concurrent.futures as cf,time,json,pickle,sys
OUT='/home/claude/out/raw/quickgo'; os.makedirs(OUT,exist_ok=True)
tx=[int(x) for x in open('/home/claude/out/taxids_with_proteins.txt').read().split()]
FIELDS='geneProductId,symbol,qualifier,goId,goName,goAspect,evidenceCode,goEvidence,reference,withFrom,taxonId,assignedBy,extensions,date'
def hits(b):
    u='https://www.ebi.ac.uk/QuickGO/services/annotation/search?limit=1&taxonId='+','.join(map(str,b))
    try:
        with urllib.request.urlopen(u,timeout=90) as r: return json.load(r).get('numberOfHits',0)
    except Exception: return -1
# split: big taxa alone, rest in 50s
big=[]; small=[]
for t in tx:
    pass
B=[tx[i:i+50] for i in range(0,len(tx),50)]
def fetch(i):
    fp=f'{OUT}/qg_{i:04d}.tsv.gz'
    if os.path.exists(fp) and os.path.getsize(fp)>60:
        return (i,'cached',0)
    u=('https://www.ebi.ac.uk/QuickGO/services/annotation/downloadSearch?downloadLimit=2000000'
       f'&selectedFields={FIELDS}&taxonId='+','.join(map(str,B[i])))
    for a in range(4):
        try:
            rq=urllib.request.Request(u,headers={'Accept':'text/tsv','Accept-Encoding':'gzip'})
            with urllib.request.urlopen(rq,timeout=900) as r:
                raw=r.read()
                if r.headers.get('Content-Encoding')=='gzip':
                    import io; raw=gzip.decompress(raw)
            n=raw.count(b'\n')-1
            with gzip.open(fp,'wb') as g: g.write(raw)
            return (i,'ok',n)
        except Exception as e:
            if a==3: return (i,f'FAIL {type(e).__name__} {str(e)[:60]}',0)
            time.sleep(5*(a+1))
tot=0; fails=[]; done=0
with cf.ThreadPoolExecutor(5) as ex:
    for i,st,n in ex.map(fetch,range(len(B))):
        done+=1; tot+=n
        if st.startswith('FAIL'): fails.append((i,st))
        if done%40==0: print(f'  {done}/{len(B)} batches, rows {tot:,}',flush=True)
sz=sum(os.path.getsize(f'{OUT}/{f}') for f in os.listdir(OUT))
print(f"batches {len(B)}  rows {tot:,}  failures {len(fails)}  size {sz/1e6:.1f} MB")
for i,s in fails[:12]: print('  ',i,s)
