import csv,pickle,gzip,os
from collections import Counter,defaultdict
D='/home/claude/out/deliver'
rows=list(csv.DictReader(open(f'{D}/annotation_coverage_by_virus.tsv'),delimiter='\t'))
def i(r,k): return int(r[k] or 0)
def summarize(sel,label):
    n=len(sel); c=Counter(r['coverage_class'] for r in sel)
    ex=c['EXACT_ANNOTATED']; de=c['DESCENDANT_ONLY']; no=c['NO_ANNOTATION']
    anyann=ex+de
    mf=sum(1 for r in sel if i(r,'n_go_mf')); bp=sum(1 for r in sel if i(r,'n_go_bp')); cc=sum(1 for r in sel if i(r,'n_go_cc'))
    man=sum(1 for r in sel if i(r,'n_go_manual_or_nonIEA')); iea=sum(1 for r in sel if i(r,'n_go_iea_only'))
    el=sum(1 for r in sel if i(r,'n_go_temporally_eligible'))
    gp=sum(i(r,'n_go_distinct_total') for r in sel)
    return dict(cohort=label,n_viruses=n,exact_annotated=ex,descendant_only=de,no_annotation=no,
      pct_any_annotation=round(100*anyann/n,2),pct_exact=round(100*ex/n,2),
      viruses_with_mf=mf,viruses_with_bp=bp,viruses_with_cc=cc,
      viruses_with_manual_nonIEA=man,viruses_with_iea=iea,
      viruses_with_eligible_go=el,sum_distinct_go_assignments=gp,
      family_only_promoted=0,missing=no)
allv=rows
mh=[r for r in rows if r['multi_host_benchmark']=='1']
tv=[r for r in rows if r['historical_test_virus']=='1']
out=[summarize(allv,'all_study_viruses'),summarize(mh,'multi_host_benchmark'),summarize(tv,'historical_test_viruses')]
with open(f'{D}/coverage_summary.tsv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0].keys()),delimiter='\t',lineterminator='\n')
    w.writeheader(); w.writerows(out)
for o in out:
    print(f"{o['cohort']:<26} n={o['n_viruses']:<5} exact={o['exact_annotated']:<5} strain_only={o['descendant_only']:<5} none={o['no_annotation']:<5} any={o['pct_any_annotation']}%")
# aspect/evidence breakdown table
with open(f'{D}/coverage_by_aspect_and_evidence.tsv','w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n')
    w.writerow(['cohort','metric','value'])
    for o in out:
        for k in ('viruses_with_mf','viruses_with_bp','viruses_with_cc','viruses_with_manual_nonIEA','viruses_with_iea','viruses_with_eligible_go'):
            w.writerow([o['cohort'],k,o[k]])
