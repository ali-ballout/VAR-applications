import pickle,gzip,csv,os,re
from collections import Counter
P=pickle.load(open('/home/claude/out/prot.pkl','rb'))
T=pickle.load(open('/home/claude/out/tax.pkl','rb'))
name=T['name']; D='/home/claude/out/deliver'
cols=['protein_accession','entry_name','reviewed','source_taxid','source_organism_name',
 'study_virus_taxid','study_virus_name','mapping_type','mapping_justification',
 'n_candidate_study_species','has_go_in_uniprot','protein_existence','proteomes',
 'uniprot_date_created','uniprot_date_last_modified','uniprot_release_retrieved','uniprot_release_date']
with gzip.open(f'{D}/protein_to_study_virus_mapping.tsv.gz','wt',newline='',encoding='utf-8') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n'); w.writerow(cols)
    c=Counter()
    for acc,p in P.items():
        mt=p['mapping_type']; c[mt]+=1
        just={'EXACT':'annotation organism taxid identical to study species taxid',
          'VERIFIED_DESCENDANT':'organism taxid is a descendant of exactly one study species via NCBITaxon v2026-07-12 is_a path',
          'AMBIGUOUS':'organism taxid descends from more than one study species; not resolved',
          'UNMAPPED':'organism taxid has no is_a path to any study species'}[mt]
        sv=p['study_virus_taxid']
        w.writerow([acc,p['entry_name'],p['reviewed'],p['organism_id'],p['organism'],
          sv,name.get(sv,'') if sv else '',mt,just,p['n_candidate_species'],
          'yes' if p['go_ids'].strip() else 'no',p['pe'],p['proteomes'],
          p['date_created'],p['date_modified'],'2026_04','2026-11-04'])
print("protein mapping rows:",sum(c.values()),dict(c))
# GO term labels from current ontology (clearly separated)
cov=pickle.load(open('/home/claude/out/cov.pkl','rb')); used=set(cov['gos'])
obo='/home/claude/out/raw/go-basic.obo'
terms={}
if os.path.exists(obo):
    cur=None
    op=open(obo,'rt',errors='replace')
    head=''
    for i,line in enumerate(op):
        line=line.rstrip('\n')
        if i<30 and line.startswith('data-version:'): head=line.split(':',1)[1].strip()
        if line=='[Term]': cur={'id':'','name':'','ns':'','obs':'false'}; continue
        if cur is None: continue
        if line.startswith('id: GO:'): cur['id']=line[4:].strip()
        elif line.startswith('name: '): cur['name']=line[6:].strip()
        elif line.startswith('namespace: '): cur['ns']=line[11:].strip()
        elif line.startswith('is_obsolete: true'): cur['obs']='true'
        elif line=='' and cur.get('id'):
            if cur['id'] in used: terms[cur['id']]=cur
            cur=None
    with open(f'{D}/go_terms_used.tsv','w',newline='') as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n')
        w.writerow(['go_id','go_name','go_namespace','is_obsolete','ontology_source','ontology_version','temporally_eligible_for_cutoff'])
        for g in sorted(used):
            t=terms.get(g,{})
            w.writerow([g,t.get('name',''),t.get('ns',''),t.get('obs',''),
              'Gene Ontology go-basic.obo',head or 'unknown','true' if (head and head.split('/')[-1]<='2026-08-18') else 'false'])
    print(f"GO terms used {len(used)}, labelled {len(terms)}, ontology data-version {head}")
else:
    print("go-basic.obo not available; GO labels omitted")
