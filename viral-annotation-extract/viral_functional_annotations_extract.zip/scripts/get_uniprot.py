import pickle,os,gzip,urllib.request,urllib.error,concurrent.futures as cf,sys,time
T=pickle.load(open('/home/claude/out/tax.pkl','rb')); study=T['study']
OUT='/home/claude/out/raw/uniprot'; os.makedirs(OUT,exist_ok=True)
F='accession,reviewed,id,protein_name,gene_names,organism_name,organism_id,go_id,go_p,go_f,go_c,date_created,date_modified,protein_existence,xref_proteomes,lineage'
B=[study[i:i+25] for i in range(0,len(study),25)]
def fetch(i):
    fp=f'{OUT}/up_{i:04d}.tsv.gz'
    if os.path.exists(fp) and os.path.getsize(fp)>40: return (i,'cached',0)
    q='+OR+'.join(f'(taxonomy_id:{t})' for t in B[i])
    u=f'https://rest.uniprot.org/uniprotkb/stream?query={q}&format=tsv&compressed=true&fields={F}'
    for a in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(u),timeout=300) as r:
                data=r.read()
            open(fp,'wb').write(data)
            n=sum(1 for _ in gzip.open(fp,'rt',errors='replace'))-1
            return (i,'ok',n)
        except Exception as e:
            if a==3: return (i,f'FAIL {type(e).__name__}',0)
            time.sleep(3*(a+1))
tot=0; fails=[]
with cf.ThreadPoolExecutor(4) as ex:
    for i,st,n in ex.map(fetch,range(len(B))):
        if st.startswith('FAIL'): fails.append((i,st))
        tot+=n
        if (i+1)%30==0: print(f'  batch {i+1}/{len(B)} rows so far {tot:,}',flush=True)
print(f"batches: {len(B)}  rows retrieved: {tot:,}  failures: {len(fails)}")
for i,s in fails[:10]: print('  FAIL batch',i,s)
print("disk:",sum(os.path.getsize(f'{OUT}/{f}') for f in os.listdir(OUT))/1e6,"MB")
