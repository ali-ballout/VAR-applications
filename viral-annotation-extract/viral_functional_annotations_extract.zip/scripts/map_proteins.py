import pickle,gzip,os,csv,sys
from collections import defaultdict,Counter
T=pickle.load(open('/home/claude/out/tax.pkl','rb'))
study=set(T['study']); desc=T['desc']; name=T['name']; rank=T['rank']
d2s=defaultdict(list)
for s,ds in desc.items():
    for d in ds: d2s[d].append(s)
OUT='/home/claude/out/raw/uniprot'
hdr=None; prot={}; amb=[]
for f in sorted(os.listdir(OUT)):
    with gzip.open(f'{OUT}/{f}','rt',errors='replace') as fh:
        rd=csv.DictReader(fh,delimiter='\t')
        for r in rd:
            acc=r['Entry']
            if acc in prot: continue
            try: oid=int(r['Organism (ID)'])
            except: continue
            if oid in study:
                mt='EXACT'; svs=[oid]
            else:
                svs=d2s.get(oid,[])
                mt='VERIFIED_DESCENDANT' if len(svs)==1 else ('AMBIGUOUS' if len(svs)>1 else 'UNMAPPED')
            if mt=='AMBIGUOUS': amb.append((acc,oid,svs))
            prot[acc]=dict(acc=acc,reviewed=r['Reviewed'],entry_name=r['Entry Name'],
                protein_name=r['Protein names'],gene=r['Gene Names'],organism=r['Organism'],
                organism_id=oid,go_ids=r['Gene Ontology IDs'],go_p=r['Gene Ontology (biological process)'],
                go_f=r['Gene Ontology (molecular function)'],go_c=r['Gene Ontology (cellular component)'],
                date_created=r['Date of creation'],date_modified=r['Date of last modification'],
                pe=r['Protein existence'],proteomes=r['Proteomes'],
                mapping_type=mt,study_virus_taxid=(svs[0] if len(svs)==1 else ''),
                n_candidate_species=len(svs))
pickle.dump(prot,open('/home/claude/out/prot.pkl','wb'),protocol=4)
c=Counter(p['mapping_type'] for p in prot.values())
print(f"proteins: {len(prot):,}")
for k,v in c.most_common(): print(f"  {k:<20}{v:>9,}")
tx=set(p['organism_id'] for p in prot.values())
print(f"distinct organism taxids: {len(tx):,}  (exact study: {len(tx&study):,}, other: {len(tx-study):,})")
covered=set(p['study_virus_taxid'] for p in prot.values() if p['study_virus_taxid'])
exact_cov=set(p['organism_id'] for p in prot.values() if p['mapping_type']=='EXACT')
print(f"study viruses with >=1 protein (exact or strain): {len(covered):,}/3288")
print(f"  of which exact-taxon proteins: {len(exact_cov):,}")
withgo=set(p['study_virus_taxid'] for p in prot.values() if p['study_virus_taxid'] and p['go_ids'].strip())
print(f"study viruses with >=1 GO-annotated protein: {len(withgo):,}/3288")
print(f"ambiguous (strain under >1 study species): {len(amb):,}")
open('/home/claude/out/taxids_with_proteins.txt','w').write('\n'.join(map(str,sorted(tx))))
