import os,gzip,csv,pickle,datetime,json
from collections import defaultdict,Counter
T=pickle.load(open('/home/claude/out/tax.pkl','rb'))
studyL=T['study']; study=set(studyL); desc=T['desc']; name=T['name']; fam=T['fam']; rows_meta=T['rows']
d2s=defaultdict(list)
for s,ds in desc.items():
    for d in ds: d2s[d].append(s)
CUT='2026-08-18'; QG='/home/claude/out/raw/quickgo'
D='/home/claude/out/deliver'; os.makedirs(D,exist_ok=True)
ASP={'F':'molecular_function','P':'biological_process','C':'cellular_component'}
SRC_URL='https://www.ebi.ac.uk/QuickGO/services/annotation/downloadSearch'
RETR=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
SRCREL='2026-07-28'
SRCRES='QuickGO annotation snapshot 2026-07-28 10:08 UTC (UniProt-GOA release 236; corroborated by GOA archive Last-Modified 2026-07-29)'
ELIGB='snapshot_verified:quickgo_annotation_about_timestamp_2026-07-28<=cutoff_2026-08-18'
HDR=['study_virus_taxid','source_taxid','protein_accession','go_id','controlled_trait_id',
 'go_aspect_or_trait_type','evidence_code','eco_id','qualifier','reference','with_from','assigned_by',
 'annotation_date','source_release_date','source_resource','source_url','mapping_type',
 'mapping_confidence','temporally_eligible','eligibility_basis','source_file','source_line_or_record_id']
main=gzip.open(f'{D}/viral_functional_annotations.tsv.gz','wt',newline='',encoding='utf-8')
mw=csv.writer(main,delimiter='\t',lineterminator='\n'); mw.writerow(HDR)
unm=gzip.open(f'{D}/unmapped_annotation_records.tsv.gz','wt',newline='',encoding='utf-8')
uw=csv.writer(unm,delimiter='\t',lineterminator='\n'); uw.writerow(HDR)
per=defaultdict(lambda: dict(exact_go=set(),desc_go=set(),exact_prot=set(),desc_prot=set(),
  mf=set(),bp=set(),cc=set(),man=set(),iea=set(),elig=set(),nonelig=set(),dtx=set()))
MANUAL={'EXP','IDA','IPI','IMP','IGI','IEP','HTP','HDA','HMP','HGI','HEP','TAS','IC','NAS',
        'ISS','ISO','ISA','ISM','IGC','IBA','IKR','IRD','RCA'}
mt_c=Counter(); elig_c=Counter(); unmapped=Counter(); gos=set(); n=0; nmain=0; nun=0
for fn in sorted(os.listdir(QG)):
    if not fn.endswith('.tsv.gz'): continue
    with gzip.open(f'{QG}/{fn}','rt',errors='replace') as fh:
        for ln,line in enumerate(fh):
            if ln==0: continue
            p=line.rstrip('\n').split('\t')
            if len(p)<15: continue
            n+=1
            acc,qual,go,asp,eco,ev,ref,wf,tx,ab,dt=p[1],p[3],p[4],p[6],p[7],p[8],p[9],p[10],p[11],p[12],p[14]
            try: txi=int(tx)
            except: continue
            if txi in study: mt,svs,mc='EXACT',[txi],'identity'
            else:
                svs=d2s.get(txi,[])
                if len(svs)==1: mt,mc='VERIFIED_DESCENDANT','descendant_path_ncbitaxon_v2026-07-12'
                elif len(svs)>1: mt,mc='AMBIGUOUS','multiple_candidate_species'
                else: mt,mc='UNMAPPED','no_path_to_study_species'; unmapped[txi]+=1
            ad=f'{dt[:4]}-{dt[4:6]}-{dt[6:8]}' if len(dt)==8 else ''
            el='true' if (ad and ad<=CUT) else 'false'
            mt_c[mt]+=1; elig_c[el]+=1
            sv=svs[0] if len(svs)==1 else ''
            row=[sv,txi,acc,go,'',ASP.get(asp,asp),ev,eco,qual,ref,wf,ab,ad,SRCREL,SRCRES,SRC_URL,mt,mc,el,ELIGB,fn,ln+1]
            if sv:
                mw.writerow(row); nmain+=1; gos.add(go)
                d=per[sv]
                if mt=='EXACT': d['exact_go'].add(go); d['exact_prot'].add(acc)
                else: d['desc_go'].add(go); d['desc_prot'].add(acc); d['dtx'].add(txi)
                a=ASP.get(asp,asp)
                (d['mf'] if a=='molecular_function' else d['bp'] if a=='biological_process' else d['cc']).add(go)
                (d['man'] if ev in MANUAL else d['iea']).add(go)
                (d['elig'] if el=='true' else d['nonelig']).add(go)
            else:
                uw.writerow(row); nun+=1
main.close(); unm.close()
print(f"rows read {n:,} | mapped->main {nmain:,} | unmapped->separate {nun:,}")
print("mapping_type:",dict(mt_c),"| eligible:",dict(elig_c))
# per-virus coverage
flags={int(r['study_virus_taxid']):r for r in rows_meta}
cls=Counter()
with open(f'{D}/annotation_coverage_by_virus.tsv','w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n')
    w.writerow(['study_virus_taxid','scientific_name','viral_family_ncbitaxon','multi_host_benchmark',
      'historical_test_virus','coverage_class','n_exact_proteins','n_descendant_proteins',
      'n_descendant_taxids_annotated','n_descendant_taxids_total','n_go_exact','n_go_descendant',
      'n_go_distinct_total','n_go_mf','n_go_bp','n_go_cc','n_go_manual_or_nonIEA','n_go_iea_only',
      'n_go_temporally_eligible','n_go_not_eligible'])
    for t in studyL:
        r=flags[t]; d=per.get(t)
        c='EXACT_ANNOTATED' if (d and d['exact_go']) else ('DESCENDANT_ONLY' if (d and d['desc_go']) else 'NO_ANNOTATION')
        cls[c]+=1
        if d:
            allg=d['exact_go']|d['desc_go']
            w.writerow([t,r['scientific_name'],fam[t],r['multi_host_benchmark'],r['historical_test_virus'],c,
              len(d['exact_prot']),len(d['desc_prot']),len(d['dtx']),len(desc[t]),
              len(d['exact_go']),len(d['desc_go']),len(allg),len(d['mf']),len(d['bp']),len(d['cc']),
              len(d['man']),len(d['iea']-d['man']),len(d['elig']),len(d['nonelig'])])
        else:
            w.writerow([t,r['scientific_name'],fam[t],r['multi_host_benchmark'],r['historical_test_virus'],c,
              0,0,0,len(desc[t]),0,0,0,0,0,0,0,0,0,0])
print("coverage:",dict(cls))
with open(f'{D}/unmatched_identifiers.tsv','w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n')
    w.writerow(['identifier_type','identifier','n_annotation_rows','reason'])
    for t,c in unmapped.most_common():
        w.writerow(['annotation_source_taxid',t,c,'no descendant path to any of the 3288 study species in NCBITaxon v2026-07-12'])
    for t in studyL:
        if t not in per:
            w.writerow(['study_virus_taxid',t,0,'no GO annotation for this species or any descendant in QuickGO snapshot 2026-07-28'])
with open(f'{D}/ambiguous_mappings.tsv','w',newline='') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n')
    w.writerow(['source_taxid','candidate_study_species','n_candidates','resolution'])
    amb=[(t,v) for t,v in d2s.items() if len(v)>1]
    for t,v in amb: w.writerow([t,';'.join(map(str,v)),len(v),'left unresolved; excluded from species annotations'])
    print("ambiguous strain->species cases:",len(amb))
pickle.dump(dict(per={k:{kk:(len(vv) if isinstance(vv,set) else vv) for kk,vv in v.items()} for k,v in per.items()},
  cls=dict(cls),mt=dict(mt_c),gos=sorted(gos),nmain=nmain,nun=nun),open('/home/claude/out/cov.pkl','wb'),protocol=4)
print("distinct GO terms used:",len(gos))
for fl in sorted(os.listdir(D)): print(f"  {fl}  {os.path.getsize(D+'/'+fl)/1e6:.2f} MB")
