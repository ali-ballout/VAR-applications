import re,os,gzip,time,csv,urllib.request,pickle
OUT='/home/claude/out/raw/viralzone'; os.makedirs(OUT,exist_ok=True)
UA='Mozilla/5.0 (compatible; academic virus annotation study)'
sm_p=f'{OUT}/sitemap.xml'
if not os.path.exists(sm_p):
    with urllib.request.urlopen(urllib.request.Request('https://viralzone.expasy.org/sitemap.xml',headers={'User-Agent':UA}),timeout=60) as r:
        open(sm_p,'wb').write(r.read())
sm=open(sm_p,encoding='utf-8',errors='replace').read()
seen=set(); pages=[]
for url,pid in re.findall(r'<loc>(https://viralzone\.expasy\.org/(\d+))</loc>',sm):
    if pid not in seen: seen.add(pid); pages.append((url,pid))
idx=[]
for i,(url,pid) in enumerate(pages):
    fp=f'{OUT}/vz_{pid}.html.gz'
    if os.path.exists(fp):
        html=gzip.open(fp,'rt',encoding='utf-8',errors='replace').read()
    else:
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':UA}),timeout=40) as r:
                html=r.read().decode('utf-8','replace')
            with gzip.open(fp,'wt',encoding='utf-8') as g: g.write(html)
            time.sleep(0.4)
        except Exception as e:
            idx.append(dict(page_id=pid,url=url,title='',h1='',bytes=0,error=str(e)[:100])); continue
    t=re.search(r'<title>([^<]*)</title>',html); h=re.search(r'<h1[^>]*>([^<]*)',html)
    idx.append(dict(page_id=pid,url=url,
        title=(t.group(1) if t else '').replace('~ ViralZone','').strip(),
        h1=(h.group(1) if h else '').strip(),bytes=len(html),error=''))
    if (i+1)%200==0: print(' vz',i+1,flush=True)
with open('/home/claude/out/viralzone_page_index.tsv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['page_id','url','title','h1','bytes','error'],delimiter='\t')
    w.writeheader(); w.writerows(idx)
print('vz pages indexed',len(idx),'errors',sum(1 for r in idx if r['error']))
