import os,json,hashlib,shutil,datetime,csv,gzip,subprocess,pickle
OUT='/home/claude/out'; D=f'{OUT}/deliver'; PKG=f'{OUT}/package'
if os.path.exists(PKG): shutil.rmtree(PKG)
os.makedirs(f'{PKG}/scripts'); os.makedirs(f'{PKG}/raw')
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda: f.read(1<<20),b''): h.update(c)
    return h.hexdigest()
# normalized outputs
for f in sorted(os.listdir(D)): shutil.copy2(f'{D}/{f}',f'{PKG}/{f}')
# raw sources
for sub in ('quickgo','uniprot','viralzone'):
    shutil.copytree(f'{OUT}/raw/{sub}',f'{PKG}/raw/{sub}')
shutil.copy2(f'{OUT}/raw/go-basic.obo.gz',f'{PKG}/raw/go-basic.obo.gz')
os.makedirs(f'{PKG}/raw/provenance',exist_ok=True)
for f in os.listdir(f'{OUT}/prov'): shutil.copy2(f'{OUT}/prov/{f}',f'{PKG}/raw/provenance/{f}')
# scripts
for s in ('taxtree.py','get_uniprot.py','map_proteins.py','get_quickgo.py','count_all.py',
          'build_outputs.py','cohorts.py','mapping_and_go.py','get_viralzone.py','vz_traits.py','package.py'):
    p=f'/home/claude/bin/{s}'
    if os.path.exists(p): shutil.copy2(p,f'{PKG}/scripts/{s}')
open(f'{PKG}/scripts/requirements.txt','w').write("# stdlib only (python >=3.9); no third-party packages required\n")
open(f'{PKG}/scripts/RUN_ORDER.txt','w').write(
"""Reproduction order (stdlib python3 only; each script is independent and resumable):
 1 taxtree.py        parse pinned NCBITaxon v2026-07-12 -> tax.pkl (needs VIRUS_ONTOLOGY_SOURCES.zip from the handoff)
 2 get_uniprot.py    UniProt REST, taxonomy_id batches of 25 -> raw/uniprot/*.tsv.gz
 3 map_proteins.py   classify protein organism taxid vs study species -> prot.pkl, taxids_with_proteins.txt
 4 count_all.py      QuickGO hit counts (volume check before download)
 5 get_quickgo.py    QuickGO downloadSearch, taxonId batches of 50 -> raw/quickgo/*.tsv.gz
 6 build_outputs.py  normalize -> viral_functional_annotations.tsv.gz + coverage + unmatched + ambiguous
 7 cohorts.py        coverage_summary.tsv for 3288 / 406 / 54
 8 mapping_and_go.py protein_to_study_virus_mapping.tsv.gz + go_terms_used.tsv
 9 get_viralzone.py  ViralZone pages (0.4s delay) -> raw/viralzone/
10 vz_traits.py      family-level traits with host-leakage exclusion
11 package.py        manifest + checksums + zip
""")
CUT='2026-08-18'
sources=[
 dict(resource='UniProt-GOA via QuickGO',role='GO annotations (primary evidence)',
   version='annotation snapshot 2026-07-28 10:08 UTC',release_date='2026-07-28',
   endpoint='https://www.ebi.ac.uk/QuickGO/services/annotation/downloadSearch',
   version_evidence='https://www.ebi.ac.uk/QuickGO/services/annotation/about -> {"annotation":{"timestamp":"2026-07-28 10:08"}} (saved: raw/provenance/quickgo_annotation_about.json)',
   corroboration='ftp.ebi.ac.uk GOA archive goa_uniprot_all.gaf.236.gz Last-Modified Wed, 29 Jul 2026 16:10:33 GMT, Content-Length 11714420656 (saved: raw/provenance/goa_236_headers.txt)',
   temporally_eligible=True,eligibility_basis=f'dated snapshot 2026-07-28 <= cutoff {CUT}',
   license='GOA: CC BY 4.0', published_checksum=None,
   checksum_note='QuickGO REST responses are generated per query; the service publishes no file checksums. SHA-256 of every retrieved file is recorded below and was computed locally.',
   files_dir='raw/quickgo'),
 dict(resource='UniProtKB',role='protein records / accession + organism mapping',
   version='2026_04',release_date='2026-11-04',
   endpoint='https://rest.uniprot.org/uniprotkb/stream',
   version_evidence='HTTP response headers x-uniprot-release: 2026_04, x-uniprot-release-date: 04-November-2026',
   corroboration=None,
   temporally_eligible=False,
   eligibility_basis=f'release 2026-11-04 is AFTER cutoff {CUT}; used only for protein identity/organism mapping, NOT as annotation evidence',
   license='CC BY 4.0', published_checksum=None,
   checksum_note='REST query results; no publisher checksum exists. Local SHA-256 recorded.',
   files_dir='raw/uniprot'),
 dict(resource='Gene Ontology (go-basic.obo)',role='GO term labels and namespaces only',
   version='releases/2026-07-26',release_date='2026-07-26',
   endpoint='https://current.geneontology.org/ontology/go-basic.obo',
   version_evidence='data-version: releases/2026-07-26 (line 2 of the file)',
   corroboration=None,temporally_eligible=True,
   eligibility_basis=f'ontology release 2026-07-26 <= cutoff {CUT}',
   license='CC BY 4.0',published_checksum=None,
   checksum_note='current.geneontology.org publishes no checksum for go-basic.obo. Local SHA-256 recorded.',
   files_dir='raw/go-basic.obo.gz'),
 dict(resource='ViralZone (ExPASy/SIB)',role='family-level descriptive traits (NOT species annotations)',
   version='rolling web resource, no release identifier',release_date=None,
   endpoint='https://viralzone.expasy.org/<page_id>',
   version_evidence='none published; retrieval timestamp recorded per row',
   corroboration=None,temporally_eligible=False,
   eligibility_basis='ViralZone publishes no dated release; temporal eligibility cannot be established',
   license='ViralZone terms (academic use); see https://viralzone.expasy.org/',
   published_checksum=None,
   checksum_note='No publisher checksum. Local SHA-256 recorded per page.',
   files_dir='raw/viralzone'),
 dict(resource='NCBITaxon (pinned by the handoff package)',role='taxonomy tree for strain->species resolution',
   version='v2026-07-12',release_date='2026-07-12',
   endpoint='https://github.com/obophenotype/ncbitaxon/releases/download/v2026-07-12/ncbitaxon.obo.gz',
   version_evidence="reference/DOWNLOAD_MANIFEST.json in the user's handoff package",
   corroboration='sha256 b502d5fd4082e3dbc1ade722142d898f4683bd53f7b5903fbe1dff4d42f65bcc verified against the handoff manifest before use',
   temporally_eligible=True,eligibility_basis=f'release 2026-07-12 <= cutoff {CUT}',
   license='CC0 / NCBI terms',published_checksum='b502d5fd4082e3dbc1ade722142d898f4683bd53f7b5903fbe1dff4d42f65bcc',
   checksum_note='Published digest from the handoff manifest; verified match. File NOT duplicated here (50 MB, already in the user package).',
   files_dir=None),
]
files=[]
for root,_,fns in os.walk(PKG):
    for fn in sorted(fns):
        p=os.path.join(root,fn); rel=os.path.relpath(p,PKG)
        files.append(dict(path=rel,bytes=os.path.getsize(p),sha256=sha(p)))
man=dict(
 created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 study=dict(n_viruses=3288,n_multi_host=406,n_historical_test=54,
   input_file_sha256='45e4781dfc5c26a7191dd1315dd3b962077c5510526955c734514c416c02f89b',
   input_file='input/study_virus_ids.tsv (from handoff package, verified)'),
 historical_cutoff=CUT,
 what_this_is='Targeted extraction of virus-specific functional annotations for exactly the 3288 study TaxIDs. No complete database mirror was downloaded or redistributed.',
 sources=sources,
 constraints_observed=[
  'No virus-host association labels were used at any point.',
  'No prediction model was trained; no similarity was computed.',
  'Family-level ViralZone text is labelled FAMILY_ONLY and was never promoted to species annotations.',
  'Strain/isolate annotations are kept as VERIFIED_DESCENDANT with their original taxid and accession; never relabelled as species-level evidence.',
  'Missing annotation is recorded as missing, never as a biological negative.',
  'ViralZone sections matching host/receptor/tropism/transmission/vector/reservoir/pathology/epidemiology patterns were withheld (text blanked, row retained with EXCLUDED_HOST_LEAKAGE_RISK) to prevent label leakage.',
 ],
 files=files,
 total_bytes=sum(f['bytes'] for f in files),
)
json.dump(man,open(f'{PKG}/download_manifest.json','w'),indent=1)
print('manifest files:',len(files),'bytes',man['total_bytes'])
