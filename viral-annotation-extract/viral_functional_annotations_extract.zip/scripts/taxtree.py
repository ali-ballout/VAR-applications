import gzip,pickle,csv,sys
OBO='/home/claude/pkg/onto/historical/v2026-07-12/ncbitaxon.obo.gz'
parent={};rank={};name={};cur=None
for line in gzip.open(OBO,'rt',encoding='utf-8',errors='replace'):
    line=line.rstrip('\n')
    if line=='[Term]': cur=None; continue
    if line.startswith('id: NCBITaxon:'):
        v=line[14:].strip(); cur=int(v) if v.isdigit() else None; continue
    if cur is None: continue
    if line.startswith('name: '): name[cur]=line[6:].strip()
    elif line.startswith('is_a: NCBITaxon:'):
        p=line[16:].split('!')[0].strip()
        if p.isdigit(): parent[cur]=int(p)
    elif 'has_rank' in line and 'NCBITaxon:' in line:
        rank[cur]=line.rsplit('NCBITaxon:',1)[1].strip().strip('"')
children={}
for c,p in parent.items(): children.setdefault(p,[]).append(c)
rows=list(csv.DictReader(open('/home/claude/pkg/input/study_virus_ids.tsv'),delimiter='\t'))
study=[int(r['study_virus_taxid']) for r in rows]
desc={}
for t in study:
    seen=set();st=[t]
    while st:
        n=st.pop()
        for ch in children.get(n,()):
            if ch not in seen: seen.add(ch); st.append(ch)
    desc[t]=seen
def lin(t):
    out=[];n=t;g=0
    while n in parent and g<60: n=parent[n];out.append(n);g+=1
    return out
lineage={t:lin(t) for t in study}
fam={}
for t in study:
    f=''
    for a in lineage[t]:
        if rank.get(a)=='family': f=name.get(a,''); break
    fam[t]=f
pickle.dump(dict(parent=parent,rank=rank,name=name,desc=desc,lineage=lineage,study=study,fam=fam,rows=rows),
            open('/home/claude/out/tax.pkl','wb'),protocol=4)
nd=sum(1 for t in study if desc[t]); tot=sum(len(v) for v in desc.values())
print(f"NCBITaxon v2026-07-12 parsed: {len(name)} taxa")
print(f"study taxids: {len(study)} (all present: {sum(1 for t in study if t in name)})")
print(f"with >=1 descendant: {nd}; total descendant taxids: {tot}")
print(f"families resolved: {sum(1 for t in study if fam[t])}/{len(study)}")
